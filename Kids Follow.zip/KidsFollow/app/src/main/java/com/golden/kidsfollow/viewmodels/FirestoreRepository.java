package com.golden.kidsfollow.viewmodels;

import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.golden.kidsfollow.models.Class;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class FirestoreRepository implements DataRepository {
    final String TAG = "FIRESTORE_REPO";

    MutableLiveData<List<Class>> classMutableLiveData;
    FirebaseFirestore db;

    private FirestoreRepository() {
        db = FirebaseFirestore.getInstance();
        initClassesLiveData();
    }

    @Override
    public LiveData<List<Class>> getClassesLiveData() {
        return null;
    }

    void initClassesLiveData() {
        classMutableLiveData = new MutableLiveData<List<Class>>(new ArrayList<Class>());
        db.collection("classes").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot documentSnapshots, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    Log.w(TAG, "onEvent:error", e);
                    return;
                }

                for (DocumentChange change : documentSnapshots.getDocumentChanges()) {
                    // Snapshot of the changed document
                    DocumentSnapshot snapshot = change.getDocument();

                    switch (change.getType()) {
                        case ADDED:
                            classMutableLiveData.getValue().add(Class.fromSnapshot(change.getDocument()));
                            break;
                        case MODIFIED:
                            // TODO: handle document modified
                            break;
                        case REMOVED:
                            // TODO: handle document removed
                            break;
                    }
                }
            }
        });
    }
}
