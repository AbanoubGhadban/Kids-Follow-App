package com.golden.kidsfollow.viewmodels;

import androidx.lifecycle.ViewModel;

public class MainActivityViewModel extends ViewModel {
}
