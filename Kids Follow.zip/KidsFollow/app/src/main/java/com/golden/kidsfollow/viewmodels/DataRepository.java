package com.golden.kidsfollow.viewmodels;

import androidx.lifecycle.LiveData;

import java.util.List;

public interface DataRepository {
    LiveData<List<Class>> getClassesLiveData();
}
