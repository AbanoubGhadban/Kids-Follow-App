package com.golden.kidsfollow.models;

import com.google.firebase.firestore.DocumentSnapshot;

public class Class {
    private String id;
    private String name;

    public Class(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public static Class fromSnapshot(DocumentSnapshot snapshot) {
        return new Class(snapshot.getId(), snapshot.getString("name"));
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
